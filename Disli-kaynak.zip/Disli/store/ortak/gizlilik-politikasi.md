# Dişli gizlilik politikası

Bu metni herkese açık bir sayfada (ör. aslaninteraktif.com/disli/gizlilik) yayınla ve adresini
hem App Store Connect'e hem Google Play Console'a yaz. `<...>` yerlerini doldur.

```
Dişli Gizlilik Politikası
Son güncelleme: <tarih>

Dişli kişisel veri toplamaz ve kimseyle paylaşmaz.

Oyundaki ilerlemen (açılan bölümler, yıldızlar ve ses ayarı) cihazında saklanır; geliştirici bu veriye erişmez. Telefonunun kendi yedekleme özelliği (Google yedekleme / iCloud) açıksa, bu bilgiler cihaz yedeğinin parçası olarak yedeklenip geri yüklenebilir.

Uygulamada hesap, giriş, reklam, analiz aracı ya da uygulama içi satın alma yoktur.

Sorular için: <e-posta adresin>
```
