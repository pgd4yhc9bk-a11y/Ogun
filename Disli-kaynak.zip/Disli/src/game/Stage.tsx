import { useEffect, useMemo, useState } from 'react';
import { StyleSheet, View, type LayoutChangeEvent } from 'react-native';
import { SkiaPictureView, createPicture, useTypeface, type SkPicture } from '@shopify/react-native-skia';
import { Rubik_800ExtraBold } from '@expo-google-fonts/rubik/800ExtraBold';
import { drawGame, makePainter } from './draw';
import type { Colors, DisliGame } from './logic';

type Props = {
  game: DisliGame;
  colors: Colors;
  active: boolean;   // false iken döngü durur: uygulama arka planda, intro sürüyor ya da tam kaplayan panel açık
};

// Oyun alanı: Skia tuvali, kare döngüsü ve dokunma.
export default function Stage({ game, colors, active }: Props) {
  const typeface = useTypeface(Rubik_800ExtraBold);
  const painter = useMemo(() => makePainter(typeface), [typeface]);
  const [size, setSize] = useState<{ w: number; h: number } | null>(null);
  const [picture, setPicture] = useState<SkPicture | null>(null);

  const onLayout = (e: LayoutChangeEvent) => {
    const { width, height } = e.nativeEvent.layout;
    if (width > 0 && height > 0) setSize({ w: width, h: height });
  };

  useEffect(() => {
    if (size) game.setSize(size.w, size.h);
  }, [game, size]);

  // Kare döngüsü. Ekran her yenilendiğinde tetiklenir ama son çizimden bu yana 9 ms geçmediyse
  // o kare atlanır: 120 Hz'de ~60 fps, 90 Hz ve 60 Hz'de her kare. 9 ms, 90 Hz'in 11,1 ms'lik
  // aralığına sapma payı bırakır.
  useEffect(() => {
    if (!active || !size) return;
    let raf = 0;
    let last = performance.now();
    const frame = () => {
      raf = requestAnimationFrame(frame);
      const now = performance.now();
      if (now - last < 9) return;
      game.update((now - last) / 1000);
      last = now;
      setPicture(createPicture(c => drawGame(c, game, colors, painter, now), { width: size.w, height: size.h }));
    };
    raf = requestAnimationFrame(frame);
    return () => cancelAnimationFrame(raf);
  }, [game, size, active, colors, painter]);

  return (
    <View
      style={StyleSheet.absoluteFill}
      onLayout={onLayout}
      accessible
      accessibilityRole="button"
      accessibilityLabel="Oyun alanı. Dişi boşluğa denk getirip dokun."
      onStartShouldSetResponder={() => game.overlay === null}
      onResponderGrant={() => game.tap()}
    >
      {size && picture && (
        <SkiaPictureView picture={picture} style={StyleSheet.absoluteFill} pointerEvents="none" />
      )}
    </View>
  );
}
