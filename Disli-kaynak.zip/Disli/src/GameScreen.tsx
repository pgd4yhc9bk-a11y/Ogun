import { useEffect, useMemo, useReducer, useRef, useState } from 'react';
import { AccessibilityInfo, AppState, BackHandler, Pressable, StyleSheet, View, useColorScheme } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Canvas, Path } from '@shopify/react-native-skia';
import { useFonts } from 'expo-font';
import { Rubik_500Medium } from '@expo-google-fonts/rubik/500Medium';
import { Rubik_700Bold } from '@expo-google-fonts/rubik/700Bold';
import { Rubik_800ExtraBold } from '@expo-google-fonts/rubik/800ExtraBold';
import Stage from './game/Stage';
import Menus, { type Actions } from './game/ui/Menus';
import { FONT, Txt } from './game/ui/kit';
import { DisliGame, PALETTE, normalizeProgress, type Overlay } from './game/logic';
import { loadProgress, saveProgress } from './game/storage';
import { initFeedback, playFx, releaseFeedback } from './game/feedback';

// Oyun alanını tamamen örten paneller: açıkken çizim döngüsü durur.
const SOLID: Overlay[] = ['levels', 'reset'];

const ICON = {
  menu: 'M4 7h16M4 12h16M4 17h16',
  soundOn: 'M11 5 6 9H3v6h3l5 4z M15.5 8.5a5 5 0 0 1 0 7 M18.5 5.5a9 9 0 0 1 0 13',
  soundOff: 'M11 5 6 9H3v6h3l5 4z M16 9l5 6 M21 9l-5 6',
};

function Icon({ path, color, width }: { path: string; color: string; width: number }) {
  return (
    <Canvas style={styles.iconCanvas} pointerEvents="none">
      <Path path={path} style="stroke" strokeWidth={width} strokeCap="round" strokeJoin="round" color={color} />
    </Canvas>
  );
}

type Props = {
  visible?: boolean;       // intro bitip oyun göründüğünde true
  onReady?: () => void;    // yazı tipleri ve ilerleme yüklenip oyun çizilebilir olunca bir kez
};

export default function GameScreen({ visible = true, onReady }: Props) {
  const scheme = useColorScheme() === 'dark' ? 'dark' : 'light';
  // Yazı tipi yüklenemezse oyun telefonun kendi yazı tipiyle açılır, boş ekranda kalmaz.
  const [fontsLoaded, fontError] = useFonts({ Rubik_500Medium, Rubik_700Bold, Rubik_800ExtraBold });
  const [game, setGame] = useState<DisliGame | null>(null);
  const [, rerender] = useReducer((n: number) => n + 1, 0);
  const [active, setActive] = useState(AppState.currentState === 'active');
  const gameRef = useRef<DisliGame | null>(null);
  const readySent = useRef(false);

  useEffect(() => {
    let alive = true;
    initFeedback();
    loadProgress().catch(() => normalizeProgress({})).then(p => {
      if (!alive) return;
      const g: DisliGame = new DisliGame(p, {
        save: saveProgress,
        fx: f => playFx(f, g.soundOn),
        change: rerender,
      });
      gameRef.current = g;
      setGame(g);
    });
    return () => { alive = false; releaseFeedback(); };
  }, []);

  // hareket azaltma ayarı: sarsıntı ve yıldız zıplaması kapanır
  useEffect(() => {
    const apply = (on: boolean) => { if (gameRef.current) gameRef.current.reduceMotion = on; };
    AccessibilityInfo.isReduceMotionEnabled().then(apply, () => {});
    const sub = AccessibilityInfo.addEventListener('reduceMotionChanged', apply);
    return () => sub.remove();
  }, [game]);

  // alta alınınca oyun duraklar, çizim döngüsü durur
  useEffect(() => {
    const sub = AppState.addEventListener('change', next => {
      const g = gameRef.current;
      if (next !== 'active' && g && (g.state === 'hover' || g.state === 'drop')) g.goHome();
      setActive(next === 'active');
    });
    return () => sub.remove();
  }, []);

  // Android geri tuşu: ana menüdeyken uygulamadan çıkar, başka yerde ana menüye döner
  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      const g = gameRef.current;
      if (!g || g.overlay === 'home') return false;
      g.goHome();
      return true;
    });
    return () => sub.remove();
  }, []);

  const colors = PALETTE[scheme];

  const act = useMemo<Actions | null>(() => {
    if (!game) return null;
    return {
      play: () => game.pressPlay(),
      levels: () => game.openLevels(),
      pickLevel: l => game.pickLevel(l),
      back: () => game.backToHome(),
      retry: () => game.retry(),
      failHome: () => game.failHome(),
      askReset: () => game.askReset(),
      resetYes: () => game.confirmReset(),
      resetNo: () => game.cancelReset(),
    };
  }, [game]);

  const ready = !!(game && act && (fontsLoaded || fontError));

  useEffect(() => {
    if (ready && !readySent.current) { readySent.current = true; onReady?.(); }
  }, [ready, onReady]);

  return (
    <SafeAreaView style={[styles.root, { backgroundColor: colors.bg }]} edges={['top', 'bottom']}>
      {ready && game && act && (
        <View style={styles.app}>
          <View style={styles.header}>
            <Txt style={[styles.mark, { color: colors.ink }]}>Dişli</Txt>
            <View style={styles.hr}>
              <Txt style={[styles.best, { color: colors.muted }]}>{'En iyi: ' + game.best}</Txt>
              <Pressable
                style={styles.icon}
                onPress={() => game.toggleSound()}
                accessibilityRole="button"
                accessibilityLabel={game.soundOn ? 'Sesi kapat' : 'Sesi aç'}
              >
                <Icon path={game.soundOn ? ICON.soundOn : ICON.soundOff} color={colors.ink} width={2} />
              </Pressable>
              <Pressable style={styles.icon} onPress={() => game.goHome()} accessibilityRole="button" accessibilityLabel="Ana menü">
                <Icon path={ICON.menu} color={colors.ink} width={2.2} />
              </Pressable>
            </View>
          </View>
          <View style={styles.stage}>
            <Stage game={game} colors={colors} active={active && visible && !SOLID.includes(game.overlay)} />
            <Menus game={game} C={colors} act={act} />
          </View>
        </View>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  app: { flex: 1, width: '100%', maxWidth: 560, alignSelf: 'center' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingTop: 6, paddingRight: 8, paddingLeft: 18 },
  mark: { fontFamily: FONT.heavy, fontSize: 23, letterSpacing: -0.5 },
  hr: { flexDirection: 'row', alignItems: 'center' },
  best: { fontFamily: FONT.medium, fontSize: 15, marginRight: 4 },
  icon: { width: 44, height: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center' },
  iconCanvas: { width: 24, height: 24 },
  stage: { flex: 1, minHeight: 0 },
});
