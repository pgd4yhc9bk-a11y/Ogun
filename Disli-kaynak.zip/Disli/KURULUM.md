# Dişli — mobil proje (Expo SDK 57)

Sapla ile aynı altyapı: Expo + React Native Skia, Aslan İnteraktif intro'su, GitHub'da Android derleme.

## İlk kurulum (bir kez)
1. GitHub'da yeni bir depo aç (ör. `Disli`) ve bu klasörün içeriğini yükle. `node_modules` yüklenmez.
2. **Expo projesine bağla.** İki yol var, biri yeterli:
   - Claude Code'da ya da bilgisayarda: `npx eas-cli@latest login` sonra `npx eas-cli@latest init`.
     `app.json`'a `expo.extra.eas.projectId` eklenir; bunu commit'le.
   - Tarayıcıdan: expo.dev → Projects → Create project → ad: `disli`. Proje sayfasındaki Project ID'yi
     kopyala, GitHub'da `app.json`'u düzenle ve `"expo"` içine şunu ekle:
     `"extra": { "eas": { "projectId": "<ID>" } }`
3. Depo ayarları → Secrets and variables → Actions → `EXPO_TOKEN`. Sapla'da kullandığın erişim kodu burada da çalışır.

## Android'i GitHub'da derlemek
Depo → **Actions → Android derle → Run workflow**, "Ne üretilsin?": `aab (Google Play)` ya da `apk (telefona kur)`.
15–25 dk sonra çalıştırmanın sayfasındaki **Artifacts → disli-android** dosyasını indir
(zip içinde `disli.aab` / `disli.apk`). Hata olursa **derleme-kaydi** dosyasına bak.
İlk derlemede Expo, Dişli için yeni bir imza anahtarı üretir ve saklar; sonraki bütün derlemeler aynı anahtarı kullanır.

## Kimlik
- Paket adı / bundle id: `com.aslaninteraktif.disli`. Mağazaya ilk yüklemeden sonra değiştirilemez.
- Uygulama adı: `Dişli`.

## iOS
Sapla ile aynı adımlar: `npx eas-cli@latest build --platform ios --profile production`, ardından
`npx eas-cli@latest submit --platform ios --latest`. App Store Connect'te yeni uygulama: `com.aslaninteraktif.disli`.

## Açılış akışı ve intro kuralı
Sapla ile aynı: splash → Aslan İnteraktif intro'su (2,5 sn, dokununca geçer) → oyun.
Intro sadece gerçek açılışta gösterilir; son kullanımdan bu yana 30 dk geçmediyse gösterilmez (`src/introGate.ts`).
Intro gösterilmeyecekse açılış ekranı oyun hazır olunca kalkar; oyun 4 sn içinde hazır olmazsa yine kalkar.

## Oyun kodu (src/game/)
- `logic.ts` — bütün mantık, saf TypeScript: tohumlu bölüm üretici (60 bölüm, prototiple birebir), dişli
  hizalama hesabı, dokunma gecikmesi telafisi (60 ms), yıldızlar, ilerleme, duraklatma.
- `draw.ts` — Skia çizimi. `Stage.tsx` — kare döngüsü (120 Hz ekranda 60 fps) ve dokunma.
- `ui/Menus.tsx`, `ui/kit.tsx` — menüler. Yazılar telefonun yazı boyutunda en fazla 1,2 kat büyür.
- `feedback.ts` — ses ve titreşim; bütün sesler açılışta hazırlanır.
- `storage.ts` — ilerleme cihazda (`disli.*` anahtarları).

## Kurallar
- Dişli, dokunduğun andaki hizaya göre oturur ya da kilitlenir (60 ms öncesine göre değerlendirilir).
- Hata < tol × 0,35 → "Tam oturdu!"; hata > tol × 0,62 → "Kıl payı!".
- Yıldız: tam oturan dişli oranı ≥ %75 → 3, ≥ %40 → 2, değilse 1. Yıldız hiçbir zaman düşmez.
- 1–3. bölümlerde temas işaretleri hizadayken yeşillenir (öğretici).
- 10'dan sonra motor hızı dalgalanır, 14'ten sonra inen dişli de döner, 20'den sonra motor arada yön değiştirir.

## Komutlar
```bash
npm install
npx tsc --noEmit
npm test
npx expo lint
node scripts/make-sounds.js      # sesleri yeniden üretir
python3 scripts/make-icons.py    # simgeleri ve mağaza görsellerini yeniden üretir
```
