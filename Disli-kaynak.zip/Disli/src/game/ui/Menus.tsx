import { Pressable, ScrollView, StyleSheet, View } from 'react-native';
import { MAX_LEVEL, type Colors, type DisliGame } from '../logic';
import { Btn, Card, CenterScroll, FONT, H1, H2, Link, Menu, Overlay, P, Txt, alpha } from './kit';

export type Actions = {
  play: () => void;
  levels: () => void;
  pickLevel: (l: number) => void;
  back: () => void;
  retry: () => void;
  failHome: () => void;
  askReset: () => void;
  resetYes: () => void;
  resetNo: () => void;
};

type Props = { game: DisliGame; C: Colors; act: Actions };

// Oyun alanının üstündeki menüler. Hangisinin açık olduğunu game.overlay belirler.
export default function Menus({ game, C, act }: Props) {
  const total = MAX_LEVEL * 3;
  switch (game.overlay) {
    case 'home': {
      const label = game.paused ? 'Devam et' : game.p.unlocked > 1 ? `Oyna (Bölüm ${game.p.level})` : 'Oyna';
      return (
        <Overlay C={C}>
          <CenterScroll>
            <Card>
              <H1 C={C}>Dişli</H1>
              <P C={C}>Dişi boşluğa denk getirip dokun, zinciri yukarı kur.</P>
              <Menu>
                <Btn C={C} label={label} onPress={act.play} />
                <Btn C={C} kind="ghost" label="Bölümler" onPress={act.levels} />
              </Menu>
              <Txt style={[styles.stat, { color: C.muted }]}>{`Yıldız: ${game.totalStars} / ${total}`}</Txt>
            </Card>
          </CenterScroll>
        </Overlay>
      );
    }
    case 'fail':
      return (
        <Overlay C={C}>
          <CenterScroll>
            <Card>
              <H2 C={C}>Kilitlendi</H2>
              <P C={C}>{`Dişler boşluğa oturmadı. Bölüm ${game.level}, ${game.placed} / ${game.cfg.K} dişli.`}</P>
              <Menu>
                <Btn C={C} label="Tekrar dene" onPress={act.retry} />
                <Btn C={C} kind="ghost" label="Ana menü" onPress={act.failHome} />
              </Menu>
            </Card>
          </CenterScroll>
        </Overlay>
      );
    case 'done':
      return (
        <Overlay C={C}>
          <CenterScroll>
            <Card>
              <H2 C={C}>Hepsi tamam!</H2>
              <P C={C}>{`${MAX_LEVEL} bölümün hepsini bitirdin. Eksik yıldızlar için bölümlere dönebilirsin.`}</P>
              <Menu>
                <Btn C={C} label="Bölümler" onPress={act.levels} />
                <Btn C={C} kind="ghost" label="Ana menü" onPress={act.back} />
              </Menu>
            </Card>
          </CenterScroll>
        </Overlay>
      );
    case 'reset':
      return (
        <Overlay C={C} solid>
          <CenterScroll>
            <Card>
              <H2 C={C}>Sıfırlansın mı?</H2>
              <P C={C}>Bütün bölümler ve yıldızlar silinir.</P>
              <Menu>
                <Btn C={C} kind="danger" label="Sıfırla" onPress={act.resetYes} />
                <Btn C={C} kind="ghost" label="Vazgeç" onPress={act.resetNo} />
              </Menu>
            </Card>
          </CenterScroll>
        </Overlay>
      );
    case 'levels':
      return (
        <Overlay C={C} solid>
          <ScrollView contentContainerStyle={styles.levels} showsVerticalScrollIndicator={false}>
            <H2 C={C}>Bölümler</H2>
            <Txt style={[styles.stat, { color: C.muted, marginTop: 0, marginBottom: 16 }]}>{`Yıldız: ${game.totalStars} / ${total}`}</Txt>
            <View style={styles.grid}>
              {Array.from({ length: MAX_LEVEL }, (_, i) => {
                const l = i + 1, open = l <= game.p.unlocked, s = game.p.stars[i];
                return (
                  <Pressable
                    key={l}
                    onPress={() => act.pickLevel(l)}
                    disabled={!open}
                    accessibilityRole="button"
                    accessibilityLabel={open ? `Bölüm ${l}, ${s} yıldız` : `Bölüm ${l}, kilitli`}
                    style={({ pressed }) => [
                      styles.cell,
                      { backgroundColor: open ? alpha(C.gearA, l === game.p.level ? 0.22 : 0.1) : 'transparent', borderColor: alpha(C.muted, open ? 0.35 : 0.2) },
                      pressed && { transform: [{ scale: 0.95 }] },
                    ]}
                  >
                    <Txt style={{ fontFamily: FONT.bold, fontSize: 17, color: open ? C.ink : alpha(C.muted, 0.6) }}>{l}</Txt>
                    <Txt style={styles.stars} accessible={false}>
                      {[0, 1, 2].map(k => (
                        <Txt key={k} style={{ color: k < s ? C.gearB : alpha(C.muted, open ? 0.45 : 0.2) }}>★</Txt>
                      ))}
                    </Txt>
                  </Pressable>
                );
              })}
            </View>
            <View style={{ marginTop: 20, alignItems: 'center' }}>
              <Btn C={C} kind="ghost" label="Geri" onPress={act.back} style={{ minWidth: 160 }} />
              <Link C={C} label="İlerlemeyi sıfırla" onPress={act.askReset} />
            </View>
          </ScrollView>
        </Overlay>
      );
    default:
      return null;
  }
}

const styles = StyleSheet.create({
  stat: { fontFamily: FONT.medium, fontSize: 15, textAlign: 'center', marginTop: 18 },
  levels: { padding: 20, paddingBottom: 32, alignItems: 'center' },
  grid: { width: '100%', maxWidth: 420, flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'center', gap: 8 },
  cell: { width: 64, height: 64, borderRadius: 12, borderWidth: 1.5, alignItems: 'center', justifyContent: 'center' },
  stars: { fontSize: 11, lineHeight: 14, marginTop: 1 },
});
