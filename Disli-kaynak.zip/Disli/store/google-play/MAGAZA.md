# Dişli — Google Play mağaza metinleri

- Uygulama adı: **Dişli**
- Kategori: Oyun → Bulmaca (ya da Arcade)
- İçerik derecelendirmesi: şiddet, reklam, satın alma yok. Hedef kitle: 13 yaş ve üzeri seçilirse
  çocuklara yönelik program kuralları devreye girmez.
- Gizlilik politikası: `store/ortak/gizlilik-politikasi.md`
- Görseller: `icon-512.png`, `feature-graphic.png` (1024×500). Ekran görüntülerini telefondan al (en az 2, dikey).

## Kısa açıklama (80 karakter)
Dişi boşluğa denk getir, dokun ve dişli zincirini yukarı kur.

## Uzun açıklama
Dişli, tek dokunuşla oynanan bir zamanlama oyunu.

Alttaki dişli dönüyor, yenisi yukarıda bekliyor. Dişi boşluğa tam denk geldiği an dokun: dişli yerine oturur, dönmeye başlar ve sıradaki ona takılır. Yanlış anda dokunursan dişler çarpışır ve zincir kilitlenir.

Her dişli farklı büyüklükte, küçükler daha hızlı döner. İlerledikçe motorun hızı dalgalanır, inen dişliler kendi de döner, motor arada yön değiştirir.

• 60 bölüm
• Tam oturan dişliler yıldız kazandırır
• Reklam yok, internet gerekmez
• Açık ve koyu tema
