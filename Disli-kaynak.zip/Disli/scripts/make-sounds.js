// Oyun seslerini üretir: assets/sounds/*.wav
// Prototip sesleri WebAudio osilatörüyle anlık üretiyordu; expo-audio dosya çaldığı için
// aynı dalga biçimi, frekans ve ses zarfı burada WAV'a yazılıyor.
// Çalıştır: node scripts/make-sounds.js
const fs = require('fs');
const path = require('path');

const RATE = 44100;
const OUT = path.join(__dirname, '..', 'assets', 'sounds');

const wave = {
  sine: p => Math.sin(2 * Math.PI * p),
  triangle: p => 1 - 4 * Math.abs(p - Math.floor(p + 0.5)),
  sawtooth: p => 2 * (p - Math.floor(p + 0.5)),
  square: p => (p - Math.floor(p) < 0.5 ? 1 : -1),
};

// tone(f, d, type, v): v'den 0.0001'e üstel sönüm, d saniye
const tone = (buf, at, f, d, type = 'triangle', v = 0.12) => {
  const start = Math.round(at * RATE), n = Math.round(d * RATE);
  for (let i = 0; i < n && start + i < buf.length; i++) {
    const t = i / RATE;
    const g = v * Math.pow(0.0001 / v, t / d);
    buf[start + i] += wave[type](f * t) * g;
  }
};

const write = (name, length, draw) => {
  const buf = new Float32Array(Math.round(length * RATE));
  draw(buf);
  const data = Buffer.alloc(buf.length * 2);
  buf.forEach((s, i) => data.writeInt16LE(Math.round(Math.max(-1, Math.min(1, s)) * 32767), i * 2));
  const h = Buffer.alloc(44);
  h.write('RIFF', 0); h.writeUInt32LE(36 + data.length, 4); h.write('WAVE', 8);
  h.write('fmt ', 12); h.writeUInt32LE(16, 16); h.writeUInt16LE(1, 20); h.writeUInt16LE(1, 22);
  h.writeUInt32LE(RATE, 24); h.writeUInt32LE(RATE * 2, 28); h.writeUInt16LE(2, 32); h.writeUInt16LE(16, 34);
  h.write('data', 36); h.writeUInt32LE(data.length, 40);
  fs.writeFileSync(path.join(OUT, name + '.wav'), Buffer.concat([h, data]));
};

fs.mkdirSync(OUT, { recursive: true });
// dişli oturdu: metal tık + alçak gövde sesi; her dişlide perde biraz yükselir (en fazla 8 dişli)
for (let step = 0; step < 8; step++) {
  write('mesh' + step, 0.09, b => {
    tone(b, 0, 1300 + step * 40, 0.03, 'square', 0.05);
    tone(b, 0, 240 + step * 22, 0.08, 'triangle', 0.14);
  });
}
write('perfect', 0.14, b => tone(b, 0.03, 1568, 0.1, 'sine', 0.07));
write('near', 0.16, b => tone(b, 0.04, 900, 0.12, 'sine', 0.07));
write('fail', 0.4, b => { tone(b, 0, 110, 0.4, 'sawtooth', 0.12); tone(b, 0.05, 95, 0.3, 'square', 0.05); });
write('win', 0.45, b => { tone(b, 0, 523, 0.12, 'triangle', 0.1); tone(b, 0.1, 659, 0.12, 'triangle', 0.1); tone(b, 0.2, 784, 0.22, 'triangle', 0.1); });
