// Dişli — oyunun bütün mantığı, saf TypeScript (arayüz yok).
// HTML prototipinden taşındı; bölüm üretici prototiple birebir aynı (aynı tohum → aynı bölüm).

export const TAU = Math.PI * 2;
export const N0 = 16;            // motor dişlisinin diş sayısı
export const TDROP = 0.1;        // inen dişlinin yerine oturma süresi (sn)
export const LAG = 0.06;         // dokunma gecikmesi telafisi (sn): gördüğün an değerlendirilir
export const MAX_LEVEL = 60;
export const PERFECT = 0.35;     // hata < tol * PERFECT → "Tam oturdu!"
export const NEAR = 0.62;        // hata > tol * NEAR   → "Kıl payı!"
const HOVER = 2.8;               // inen dişli, dişleri neredeyse değerek bekler (mm cinsinden boşluk)

// ---------- yardımcılar ----------
export const rng = (seed: number) => () => {
  seed |= 0; seed = seed + 0x6D2B79F5 | 0;
  let x = Math.imul(seed ^ seed >>> 15, 1 | seed);
  x = x + Math.imul(x ^ x >>> 7, 61 | x) ^ x;
  return ((x ^ x >>> 14) >>> 0) / 4294967296;
};
export const wrapHalf = (x: number) => x - Math.round(x);

// İki dişlinin temas noktasındaki hizalama hatası, diş aralığının kesri olarak (-0.5..0.5).
// 0: A'nın boşluğu ve B'nin dişi tam temas çizgisinde. psi: A'nın merkezinden B'nin merkezine yön.
export function meshErr(psi: number, thA: number, NA: number, thB: number, NB: number) {
  const eA = wrapHalf((psi - thA) / (TAU / NA) - 0.5);
  const eB = wrapHalf((psi + Math.PI - thB) / (TAU / NB));
  return wrapHalf(eA + eB);
}

// ---------- bölüm üretici ----------
// f: temas noktasından saniyede geçen diş sayısı (zincirin her yerinde aynı).
// tol: dişin boşluk merkezinden en fazla ne kadar kayabileceği (diş aralığının kesri).
export type LevelCfg = {
  K: number; f: number; tol: number; wobble: number; flip: number; dir: number;
  teeth: number[]; dirs: number[]; spin: number[]; phase: number[];
};

export function cfgFor(l: number): LevelCfg {
  const rnd = rng(l * 6151 + 7);
  const k = Math.min(1, (l - 1) / 40);
  const K = Math.min(8, 4 + Math.floor(l / 6));
  const f = 1.0 + k * 1.2 + rnd() * 0.2;
  const tol = 0.24 - k * 0.07;
  const wobble = l >= 10 && rnd() < 0.3 + k * 0.5 ? 0.6 + rnd() * 0.8 : 0;
  const flip = l >= 20 && rnd() < 0.2 + k * 0.5 ? Math.max(1.4, 3.2 - k * 1.5) : 0;
  const dir = rnd() < 0.5 ? 1 : -1;
  const teeth: number[] = [], dirs: number[] = [], spin: number[] = [], phase: number[] = [];
  let s = rnd() < 0.5 ? 1 : -1;
  for (let i = 0; i < K; i++) {
    teeth.push(Math.round(9 + rnd() * (11 - k * 3)));
    dirs.push(-Math.PI / 2 + s * (0.35 + rnd() * 0.35)); s = -s;
    // 14. bölümden sonra inen dişli kendi de döner: iki ritmi birlikte okumak gerekir
    spin.push(l >= 14 && rnd() < 0.3 + k * 0.5 ? (rnd() < 0.5 ? -1 : 1) * (0.25 + rnd() * 0.25) * f : 0);
    phase.push(rnd() * TAU);
  }
  return { K, f, tol, wobble, flip, dir, teeth, dirs, spin, phase };
}

// Yıldız: kaç dişli "tam oturdu".
export const starsFor = (perfects: number, K: number) => {
  const q = perfects / K;
  return q >= 0.75 ? 3 : q >= 0.4 ? 2 : 1;
};

// ---------- renkler ----------
export type Colors = {
  bg: string; ink: string; muted: string; gearA: string; gearB: string; near: string;
  hit: string; hub: string; post: string; onBtn: string; danger: string;
};
export const PALETTE: Record<'light' | 'dark', Colors> = {
  light: {
    bg: '#E4EDE8', ink: '#17302A', muted: '#526B64', gearA: '#1F6B5C', gearB: '#B97D12', near: '#8A5A00',
    hit: '#C8412F', hub: '#E4EDE8', post: '#C3D3CC', onBtn: '#FFFFFF', danger: '#C8412F',
  },
  dark: {
    bg: '#0F1E1A', ink: '#E3EFEA', muted: '#8FA9A1', gearA: '#2E9A84', gearB: '#E0A23A', near: '#E0A23A',
    hit: '#E3563F', hub: '#0F1E1A', post: '#1D332D', onBtn: '#FFFFFF', danger: '#C8412F',
  },
};

// ---------- ilerleme ----------
export type Progress = { level: number; unlocked: number; stars: number[]; sound: boolean };
export const PROGRESS_KEYS = ['level', 'unlocked', 'stars', 'sound'] as const;
export type ProgressKey = typeof PROGRESS_KEYS[number];

const clampInt = (v: unknown, lo: number, hi: number, d: number) =>
  typeof v === 'number' && Number.isFinite(v) ? Math.max(lo, Math.min(hi, Math.round(v))) : d;

export function normalizeProgress(raw: Partial<Record<ProgressKey, unknown>>): Progress {
  const unlocked = clampInt(raw.unlocked, 1, MAX_LEVEL, 1);
  const level = Math.min(unlocked, clampInt(raw.level, 1, MAX_LEVEL, 1));
  const stars = Array.from({ length: MAX_LEVEL }, (_, i) =>
    Array.isArray(raw.stars) ? clampInt(raw.stars[i], 0, 3, 0) : 0);
  return { level, unlocked, stars, sound: raw.sound !== false };
}

// ---------- oyun ----------
export type Gear = { N: number; psi: number; ratio: number; off: number; x: number; y: number; r: number };
export type Incoming = {
  N: number; psi: number; r: number; th: number; spin: number;
  x: number; y: number; sx: number; sy: number; tx: number; ty: number;
  t: number; appear: number; ok: boolean; err: number; ratio: number; off: number;
};
export type State = 'menu' | 'hover' | 'drop' | 'win' | 'fail' | 'paused';
export type Overlay = 'home' | 'levels' | 'fail' | 'reset' | 'done' | null;
export type Fx = { type: 'mesh'; step: number } | { type: 'perfect' } | { type: 'near' } | { type: 'fail' } | { type: 'win' };

export type Hooks = {
  save: <K extends ProgressKey>(key: K, value: Progress[K]) => void;
  fx: (fx: Fx) => void;
  change: () => void;
};

export class DisliGame {
  W = 360; H = 560; mm = 8;
  gears: Gear[] = [];
  inc: Incoming | null = null;
  state: State = 'menu';
  overlay: Overlay = 'home';
  cfg: LevelCfg;
  level: number;
  placed = 0;
  perfects = 0;
  earned = 0;
  th0 = 0; om = 0; dirNow = 1; flipT = 0; t = 0; camY = -400;
  nearT = 0; nearMsg = ''; flash = 0; shake = 0; winT = 0; failTimer = -1;
  reduceMotion = false;
  p: Progress;
  private pausedFrom: State = 'hover';
  private flipRnd = rng(1);
  private hooks: Hooks;

  constructor(progress: Progress, hooks: Hooks) {
    this.p = progress;
    this.hooks = hooks;
    this.level = progress.level;
    this.cfg = cfgFor(this.level);
    this.resetChain();
  }

  get soundOn() { return this.p.sound; }
  get best() { return this.p.unlocked; }
  get totalStars() { return this.p.stars.reduce((a, b) => a + b, 0); }
  get paused() { return this.state === 'paused'; }

  thetaOf(G: Gear) { return G.off + G.ratio * this.th0; }

  setSize(w: number, h: number) {
    this.W = Math.max(200, w); this.H = Math.max(200, h);
    this.mm = Math.max(6, Math.min(9.5, Math.min(this.W * 0.021, this.H * 0.016)));
    this.layout();
    if (this.state === 'menu') this.camY = -this.H * 0.6;
  }

  // Diş sayıları ve yönlerden zincirin konumlarını yeniden kurar (ekran boyutu değişince).
  private layout() {
    const { mm } = this;
    this.gears.forEach((G, i) => {
      G.r = G.N * mm / 2;
      if (i === 0) { G.x = this.W / 2; G.y = 0; return; }
      const P = this.gears[i - 1];
      G.x = P.x + Math.cos(G.psi) * (P.r + G.r);
      G.y = P.y + Math.sin(G.psi) * (P.r + G.r);
    });
    if (this.inc) this.placeIncoming(this.inc.psi);
  }

  private resetChain() {
    this.gears = [{ N: N0, psi: 0, ratio: 1, off: 0, x: 0, y: 0, r: 0 }];
    this.inc = null;
    this.th0 = 0; this.om = 0; this.t = 0;
    this.layout();
  }

  startLevel(l: number) {
    this.level = Math.max(1, Math.min(MAX_LEVEL, l));
    this.cfg = cfgFor(this.level);
    this.p.level = this.level; this.hooks.save('level', this.level);
    this.resetChain();
    this.dirNow = this.cfg.dir; this.flipT = this.cfg.flip;
    this.flipRnd = rng(this.level * 31 + 5);
    this.placed = 0; this.perfects = 0; this.earned = 0;
    this.nearT = 0; this.flash = 0; this.shake = 0; this.winT = 0; this.failTimer = -1;
    this.camY = -this.H * 0.78;
    this.overlay = null;
    this.spawn();
    this.hooks.change();
  }

  private placeIncoming(psi: number) {
    const inc = this.inc!, A = this.gears[this.gears.length - 1];
    inc.psi = psi; inc.r = inc.N * this.mm / 2;
    inc.tx = A.x + Math.cos(psi) * (A.r + inc.r);
    inc.ty = A.y + Math.sin(psi) * (A.r + inc.r);
    const hov = this.mm * HOVER;
    inc.sx = inc.tx + Math.cos(psi) * hov; inc.sy = inc.ty + Math.sin(psi) * hov;
    if (this.state !== 'drop') { inc.x = inc.sx; inc.y = inc.sy; }
  }

  private spawn() {
    const { mm, W, cfg } = this;
    const A = this.gears[this.gears.length - 1];
    const N = cfg.teeth[this.placed], r = N * mm / 2, ra = r + mm;
    const at = (p: number) => ({ x: A.x + Math.cos(p) * (A.r + r), y: A.y + Math.sin(p) * (A.r + r) });
    const ok = (p: number) => {
      const q = at(p);
      if (q.x < ra + 6 || q.x > W - ra - 6) return false;
      return this.gears.every(G => G === A || Math.hypot(q.x - G.x, q.y - G.y) >= G.r + mm + ra + 6);
    };
    let psi = cfg.dirs[this.placed];
    if (!ok(psi)) psi = ok(Math.PI - psi) ? Math.PI - psi : -Math.PI / 2;
    this.inc = {
      N, psi, r, th: cfg.phase[this.placed], spin: cfg.spin[this.placed] * TAU / N,
      x: 0, y: 0, sx: 0, sy: 0, tx: 0, ty: 0, t: 0, appear: 0, ok: false, err: 0, ratio: 0, off: 0,
    };
    this.state = 'hover';
    this.placeIncoming(psi);
  }

  // lag > 0: dokunuştan lag saniye önceki durum (dokunma gecikmesi telafisi)
  alignErr(lag = 0) {
    const inc = this.inc!, A = this.gears[this.gears.length - 1];
    const thA = this.thetaOf(A) - A.ratio * this.om * lag;
    const thB = inc.th - inc.spin * lag;
    return meshErr(inc.psi, thA, A.N, thB, inc.N);
  }

  // Karar dokunduğun an verilir: ekranda gördüğün hiza geçerli.
  // Oturursa inen dişli iniş boyunca alttakiyle kilitli döner; oturmazsa iner ve kilitlenir.
  tap() {
    if (this.state !== 'hover' || this.overlay !== null) return;
    const inc = this.inc!, A = this.gears[this.gears.length - 1];
    inc.err = this.alignErr(LAG);
    inc.ok = Math.abs(inc.err) <= this.cfg.tol;
    if (inc.ok) {
      const thb = inc.th + this.alignErr() * (TAU / inc.N);   // şimdiki konuma göre tam hizaya oturt
      inc.ratio = -A.ratio * A.N / inc.N;
      inc.off = thb - inc.ratio * this.th0;
    }
    this.state = 'drop'; inc.t = 0;
  }

  private mesh() {
    const inc = this.inc!, { cfg } = this;
    inc.x = inc.tx; inc.y = inc.ty;
    if (!inc.ok) {
      this.state = 'fail'; this.failTimer = 0.85; this.flash = 1; this.shake = this.reduceMotion ? 0 : 1;
      this.hooks.fx({ type: 'fail' });
      return;
    }
    this.gears.push({ N: inc.N, psi: inc.psi, r: inc.r, x: inc.tx, y: inc.ty, ratio: inc.ratio, off: inc.off });
    this.inc = null;
    this.hooks.fx({ type: 'mesh', step: this.placed });
    this.placed++;
    const e = Math.abs(inc.err);
    if (e < cfg.tol * PERFECT) { this.perfects++; this.nearT = 1; this.nearMsg = 'Tam oturdu!'; this.hooks.fx({ type: 'perfect' }); }
    else if (e > cfg.tol * NEAR) { this.nearT = 1; this.nearMsg = 'Kıl payı!'; this.hooks.fx({ type: 'near' }); }
    if (this.placed >= cfg.K) this.win();
    else this.spawn();
  }

  private win() {
    this.state = 'win'; this.winT = 0;
    this.earned = starsFor(this.perfects, this.cfg.K);
    const i = this.level - 1;
    if (this.earned > this.p.stars[i]) {
      this.p.stars = this.p.stars.map((s, j) => (j === i ? this.earned : s));
      this.hooks.save('stars', this.p.stars);
    }
    const next = Math.min(MAX_LEVEL, this.level + 1);
    if (next > this.p.unlocked) { this.p.unlocked = next; this.hooks.save('unlocked', next); }
    this.hooks.fx({ type: 'win' });
    this.hooks.change();
  }

  update(elapsed: number) {
    const dt = Math.min(1 / 30, Math.max(0, elapsed));
    if (this.state === 'paused') return;
    this.t += dt;
    const { cfg } = this;

    // motor
    if (this.state === 'fail') this.om *= Math.exp(-9 * dt);
    else {
      let w = cfg.f * TAU / N0;
      if (cfg.wobble && this.state !== 'menu') w *= 0.45 + 0.9 * (0.5 + 0.5 * Math.sin(this.t * cfg.wobble));
      if (cfg.flip && this.state !== 'menu') {
        this.flipT -= dt;
        if (this.flipT <= 0) { this.dirNow = -this.dirNow; this.flipT = cfg.flip * (0.7 + this.flipRnd() * 0.6); }
      }
      this.om += (w * this.dirNow - this.om) * Math.min(1, dt * 3);
    }
    this.th0 += this.om * dt;

    // inen dişli
    const inc = this.inc;
    if (inc && (this.state === 'hover' || this.state === 'drop')) {
      if (this.state === 'drop' && inc.ok) inc.th = inc.off + inc.ratio * this.th0;
      else inc.th += inc.spin * dt;
      inc.appear = Math.min(1, inc.appear + dt * 5);
    }
    if (inc && this.state === 'hover') {
      const b = Math.sin(this.t * 3) * this.mm * 0.18;
      inc.x = inc.sx + Math.cos(inc.psi) * b; inc.y = inc.sy + Math.sin(inc.psi) * b;
    } else if (inc && this.state === 'drop') {
      inc.t += dt / TDROP;
      const e = Math.min(1, inc.t), q = e * e;
      inc.x = inc.sx + (inc.tx - inc.sx) * q; inc.y = inc.sy + (inc.ty - inc.sy) * q;
      if (inc.t >= 1) this.mesh();
    } else if (this.state === 'win') {
      this.winT += dt;
      if (this.winT > 1.8) {
        if (this.level >= MAX_LEVEL) { this.state = 'menu'; this.overlay = 'done'; this.hooks.change(); }
        else this.startLevel(this.level + 1);
      }
    }

    // kamera: inen dişli ekranın üst üçte birinde kalsın
    const top = this.gears[this.gears.length - 1];
    const focusY = this.inc ? this.inc.sy - this.inc.r : top.y - top.r;
    const target = Math.min(-this.H * 0.78, focusY - this.H * 0.24);
    if (this.state === 'menu') this.camY = -this.H * 0.6;
    else this.camY += (target - this.camY) * Math.min(1, dt * 4);

    this.nearT = Math.max(0, this.nearT - dt * 1.3);
    this.flash = Math.max(0, this.flash - dt * 2.2);
    this.shake = Math.max(0, this.shake - dt * 3);
    if (this.failTimer >= 0) {
      this.failTimer -= dt;
      if (this.failTimer < 0) { this.overlay = 'fail'; this.hooks.change(); }
    }
  }

  // ---------- menü eylemleri ----------
  pressPlay() {
    if (this.state === 'paused') { this.state = this.pausedFrom; this.overlay = null; this.hooks.change(); return; }
    this.startLevel(this.p.level);
  }

  openLevels() { this.overlay = 'levels'; this.hooks.change(); }

  pickLevel(l: number) {
    if (l < 1 || l > this.p.unlocked) return;
    this.startLevel(l);
  }

  backToHome() { this.overlay = 'home'; this.hooks.change(); }

  retry() { this.startLevel(this.level); }

  failHome() {
    this.state = 'menu'; this.overlay = 'home';
    this.resetChain();
    this.hooks.change();
  }

  // Menü düğmesi, Android geri tuşu ve uygulama alta alınınca
  goHome() {
    if (this.overlay === 'levels' || this.overlay === 'reset' || this.overlay === 'done') { this.backToHome(); return; }
    if (this.state === 'hover' || this.state === 'drop') {
      this.pausedFrom = this.state; this.state = 'paused'; this.overlay = 'home'; this.hooks.change(); return;
    }
    if (this.state === 'fail') { this.failHome(); return; }
    if (this.state === 'win') return;
    this.backToHome();
  }

  toggleSound() {
    this.p.sound = !this.p.sound;
    this.hooks.save('sound', this.p.sound);
    this.hooks.change();
  }

  askReset() { this.overlay = 'reset'; this.hooks.change(); }
  cancelReset() { this.overlay = 'levels'; this.hooks.change(); }
  confirmReset() {
    this.p.level = 1; this.p.unlocked = 1; this.p.stars = this.p.stars.map(() => 0);
    this.hooks.save('level', 1); this.hooks.save('unlocked', 1); this.hooks.save('stars', this.p.stars);
    this.level = 1; this.cfg = cfgFor(1);
    this.state = 'menu'; this.overlay = 'home';
    this.resetChain();
    this.hooks.change();
  }
}
