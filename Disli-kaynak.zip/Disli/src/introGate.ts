import AsyncStorage from '@react-native-async-storage/async-storage';
import { AppState } from 'react-native';

// KURAL: intro sadece gerçek açılışta gösterilir.
// Oyun alta alınıp geri açıldığında gösterilmez.
//
// Uygulama arka planda beklerken telefon onu hafızadan atabilir; o zaman
// geri dönmek teknik olarak "sıfırdan açılış" olur. Kullanıcı bunu yine
// geri dönüş olarak yaşar, bu yüzden son kullanımdan bu yana RESUME_WINDOW_MS
// geçmediyse intro yine gösterilmez.

const KEY = 'disli.lastActiveAt';
export const RESUME_WINDOW_MS = 30 * 60 * 1000; // 30 dk

export async function shouldShowIntro(): Promise<boolean> {
  try {
    const raw = await AsyncStorage.getItem(KEY);
    if (!raw) return true;                 // ilk kurulum
    const gap = Date.now() - Number(raw);
    if (!Number.isFinite(gap) || gap < 0) return true; // saat geri alınmış
    return gap > RESUME_WINDOW_MS;
  } catch {
    return true;
  }
}

// Son aktiflik zamanını kaydeder: arka plana geçerken ve açıkken dakikada bir.
// Android'de uygulama arka plandayken JS bir süre daha çalışabilir; dakikalık kayıt
// sadece uygulama öndeyken yapılır, yoksa 30 dk süresi arka planda uzardı.
export function trackActivity(): () => void {
  const mark = () => { AsyncStorage.setItem(KEY, String(Date.now())).catch(() => {}); };
  mark();
  const sub = AppState.addEventListener('change', state => { if (state !== 'active') mark(); });
  const timer = setInterval(() => { if (AppState.currentState === 'active') mark(); }, 60 * 1000);
  return () => { sub.remove(); clearInterval(timer); };
}
