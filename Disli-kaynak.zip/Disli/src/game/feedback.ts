import { createAudioPlayer, setAudioModeAsync, type AudioPlayer } from 'expo-audio';
import * as Haptics from 'expo-haptics';
import type { Fx } from './logic';

// Sesler scripts/make-sounds.js ile üretildi (prototipteki osilatör tonları).
const MESH = [
  require('../../assets/sounds/mesh0.wav'), require('../../assets/sounds/mesh1.wav'),
  require('../../assets/sounds/mesh2.wav'), require('../../assets/sounds/mesh3.wav'),
  require('../../assets/sounds/mesh4.wav'), require('../../assets/sounds/mesh5.wav'),
  require('../../assets/sounds/mesh6.wav'), require('../../assets/sounds/mesh7.wav'),
];
const OTHER = {
  perfect: require('../../assets/sounds/perfect.wav'),
  near: require('../../assets/sounds/near.wav'),
  fail: require('../../assets/sounds/fail.wav'),
  win: require('../../assets/sounds/win.wav'),
};

const players = new Map<number, AudioPlayer>();
const play = (source: number) => {
  try {
    let p = players.get(source);
    if (!p) { p = createAudioPlayer(source); players.set(source, p); }
    const player = p;
    player.seekTo(0).then(() => player.play(), () => player.play());
  } catch {}
};

// Sessiz moddaysa ses çalmaz, kullanıcının müziğini de kesmez (intro ile aynı).
// Bütün sesler açılışta hazırlanır: ilk dişlide gecikme olmaz.
export function initFeedback() {
  setAudioModeAsync({ playsInSilentMode: false, interruptionMode: 'mixWithOthers' }).catch(() => {});
  [...MESH, ...Object.values(OTHER)].forEach(s => {
    if (players.has(s)) return;
    try { players.set(s, createAudioPlayer(s)); } catch {}
  });
}

export function releaseFeedback() {
  players.forEach(p => { try { p.remove(); } catch {} });
  players.clear();
}

const haptic = (fx: Fx) => {
  const h =
    fx.type === 'mesh' ? Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light)
    : fx.type === 'perfect' ? Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Rigid)
    : fx.type === 'near' ? Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium)
    : fx.type === 'fail' ? Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error)
    : Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
  h.catch(() => {});
};

export function playFx(fx: Fx, soundOn: boolean) {
  haptic(fx);   // titreşim ses ayarından bağımsız
  if (!soundOn) return;
  if (fx.type === 'mesh') play(MESH[Math.max(0, Math.min(MESH.length - 1, fx.step))]);
  else play(OTHER[fx.type]);
}
