import AsyncStorage from '@react-native-async-storage/async-storage';
import { PROGRESS_KEYS, normalizeProgress, type Progress, type ProgressKey } from './logic';

// İlerleme AsyncStorage'da, her alan ayrı anahtarda: 'disli.<alan>' = JSON
const PREFIX = 'disli.';

export async function loadProgress(): Promise<Progress> {
  const raw: Partial<Record<ProgressKey, unknown>> = {};
  try {
    const rows = await AsyncStorage.multiGet(PROGRESS_KEYS.map(k => PREFIX + k));
    rows.forEach(([key, value]) => {
      if (value === null) return;
      try { raw[key.slice(PREFIX.length) as ProgressKey] = JSON.parse(value); } catch {}
    });
  } catch {}
  return normalizeProgress(raw);
}

// Intro'nun sesi için: oyunda ses kapatıldıysa intro da sessiz açılır.
export async function loadSoundOn(): Promise<boolean> {
  try {
    const v = await AsyncStorage.getItem(PREFIX + 'sound');
    return v === null ? true : JSON.parse(v) !== false;
  } catch {
    return true;
  }
}

export function saveProgress<K extends ProgressKey>(key: K, value: Progress[K]) {
  AsyncStorage.setItem(PREFIX + key, JSON.stringify(value)).catch(() => {});
}
