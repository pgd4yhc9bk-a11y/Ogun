import { afterEach, beforeEach, describe, expect, jest, test } from '@jest/globals';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { AppState } from 'react-native';
import { RESUME_WINDOW_MS, shouldShowIntro, trackActivity } from '../introGate';

// jest.mock dosyanın başına taşınır; importlar sahte AsyncStorage'ı alır.
jest.mock('@react-native-async-storage/async-storage', () =>
  jest.requireActual('@react-native-async-storage/async-storage/jest/async-storage-mock'));

const KEY = 'disli.lastActiveAt';
const flush = () => new Promise<void>(r => jest.requireActual<typeof import('timers')>('timers').setImmediate(r));

describe('intro kuralı', () => {
  let state = 'active';
  beforeEach(() => {
    jest.useFakeTimers({ now: new Date(2026, 8, 24, 12) });
    state = 'active';
    Object.defineProperty(AppState, 'currentState', { configurable: true, get: () => state });
    return AsyncStorage.clear();
  });
  afterEach(() => { jest.useRealTimers(); jest.restoreAllMocks(); });

  test('ilk açılışta intro gösterilir, 30 dk içinde geri dönüşte gösterilmez', async () => {
    expect(await shouldShowIntro()).toBe(true);
    const stop = trackActivity();
    await flush();
    jest.advanceTimersByTime(RESUME_WINDOW_MS - 60 * 1000);
    expect(await shouldShowIntro()).toBe(false);
    stop();
  });

  test('arka plandayken dakikalık kayıt yapılmaz; 30 dk sonra intro yine gösterilir', async () => {
    const stop = trackActivity();
    await flush();
    const leftAt = Number(await AsyncStorage.getItem(KEY));
    state = 'background';                      // JS arka planda çalışmaya devam ediyor
    jest.advanceTimersByTime(20 * 60 * 1000);   // 20 dk boyunca zamanlayıcı dönüyor
    await flush();
    expect(Number(await AsyncStorage.getItem(KEY))).toBe(leftAt);
    jest.setSystemTime(leftAt + RESUME_WINDOW_MS + 1000);
    expect(await shouldShowIntro()).toBe(true);
    stop();
  });
});
