import { FillType, Skia, type SkCanvas, type SkFont, type SkPaint, type SkPath, type SkTypeface } from '@shopify/react-native-skia';
import { TAU, type Colors, type DisliGame } from './logic';

// Oyun alanının Skia ile çizimi. HTML prototipindeki canvas draw() fonksiyonunun karşılığı.

export type Painter = {
  font: (px: number) => SkFont;
  gear: (N: number, mm: number) => SkPath;
};

export function makePainter(typeface: SkTypeface | null): Painter {
  const fonts = new Map<number, SkFont>();
  const gears = new Map<string, SkPath>();
  return {
    font: px => {
      const k = Math.round(px * 2) / 2;
      let f = fonts.get(k);
      if (!f) { f = typeface ? Skia.Font(typeface, k) : Skia.Font(undefined, k); fonts.set(k, f); }
      return f;
    },
    // Dişli yolu dişlinin kendi merkezinde, 0 açısında bir diş olacak şekilde kurulur; bir kez üretilir.
    gear: (N, mm) => {
      const key = N + '_' + mm;
      let p = gears.get(key);
      if (!p) { p = gearPath(N, mm); gears.set(key, p); }
      return p;
    },
  };
}

function gearPath(N: number, mm: number): SkPath {
  // Diş profili: tepe r+0.8 mm, dip r-1.0 mm; hatve çemberinde diş ≈ aralığın yarısı (gerçek dişli oranı).
  const r = N * mm / 2, ra = r + mm * 0.8, rd = r - mm * 1.0, pa = TAU / N;
  const b = Skia.PathBuilder.Make();
  for (let i = 0; i < N; i++) {
    const a = i * pa;
    const pts: [number, number][] = [[rd, a - pa * 0.5], [rd, a - pa * 0.32], [ra, a - pa * 0.18], [ra, a + pa * 0.18], [rd, a + pa * 0.32]];
    pts.forEach(([rr, aa], j) => {
      const x = Math.cos(aa) * rr, y = Math.sin(aa) * rr;
      if (i === 0 && j === 0) b.moveTo(x, y); else b.lineTo(x, y);
    });
  }
  b.close();
  b.addCircle(0, 0, Math.max(4, r * 0.18));
  if (r > mm * 4.5) {
    const n = r > mm * 7.5 ? 6 : 4, hr = r * 0.15, rr = r * 0.52;
    for (let k = 0; k < n; k++) {
      const a = (k + 0.5) * TAU / n;
      b.addCircle(Math.cos(a) * rr, Math.sin(a) * rr, hr);
    }
  }
  b.setFillType(FillType.EvenOdd);
  return b.build();
}

// Her karede yüzlerce Paint üretmemek için ortak bir Paint kullanılır. Skia çizim
// komutu kaydedilirken Paint'in o anki halini kopyaladığından bu güvenlidir.
let fillPaint: SkPaint | null = null;

const fill = (color: string, alpha = 1): SkPaint => {
  const p = fillPaint ??= Skia.Paint();
  p.setAntiAlias(true);
  p.setColor(Skia.Color(color));
  p.setAlphaf(Math.min(1, Math.max(0, alpha)));
  return p;
};

// canvas'taki textAlign 'center' + textBaseline 'middle' karşılığı
const text = (c: SkCanvas, s: string, x: number, y: number, font: SkFont, paint: SkPaint) => {
  if (!s) return;
  const w = font.getGlyphWidths(font.getGlyphIDs(s)).reduce((a, b) => a + b, 0);
  const m = font.getMetrics();
  c.drawText(s, x - w / 2, y - (m.ascent + m.descent) / 2, paint, font);
};

const DEG = 180 / Math.PI;

export function drawGame(c: SkCanvas, game: DisliGame, C: Colors, P: Painter, nowMs: number) {
  const { W, H, mm, camY, gears, inc, state, cfg, level, placed } = game;
  c.drawRect({ x: 0, y: 0, width: W, height: H }, fill(C.bg));
  if (game.flash > 0) c.drawRect({ x: 0, y: 0, width: W, height: H }, fill(C.hit, game.flash * 0.2));

  c.save();
  if (game.shake > 0) c.translate((Math.random() - 0.5) * 12 * game.shake, (Math.random() - 0.5) * 12 * game.shake);

  const drawGear = (N: number, x: number, y: number, th: number, color: string, alpha = 1) => {
    c.save();
    c.translate(x, y - camY);
    c.rotate(th * DEG, 0, 0);
    c.drawPath(P.gear(N, mm), fill(color, alpha));
    c.restore();
    c.drawCircle(x, y - camY, Math.max(2.5, mm * 0.35), fill(C.ink, alpha));
  };

  // motor ayağı
  const D0 = gears[0];
  const py = D0.y - camY;
  c.drawRect({ x: D0.x - D0.r * 0.22, y: py, width: D0.r * 0.44, height: Math.max(0, H - py + 20) }, fill(C.post));
  c.drawRect({ x: D0.x - D0.r * 1.2, y: Math.min(H - 10, py + D0.r + mm * 3), width: D0.r * 2.4, height: 40 }, fill(C.post));

  // takılı dişliler
  const failing = state === 'fail';
  gears.forEach((G, i) => {
    const jam = failing && i === gears.length - 1;
    drawGear(G.N, G.x, G.y, game.thetaOf(G), jam ? C.hit : i % 2 ? C.gearB : C.gearA);
  });

  // temas işaretleri: alttakinin hedef boşluğu ve inen dişlinin ona bakan dişi.
  // İki işaret karşı karşıya gelince dokun. İlk 3 bölümde hizadayken yeşillenir.
  let mark: { a: number; good: boolean } | null = null;
  if (inc && state === 'hover') {
    const A = gears[gears.length - 1];
    const pa = TAU / A.N, pb = TAU / inc.N;
    const thA = game.thetaOf(A);
    const gA = thA + pa * (Math.round((inc.psi - thA) / pa - 0.5) + 0.5);
    const tB = inc.th + pb * Math.round((inc.psi + Math.PI - inc.th) / pb);
    const good = level <= 3 && Math.abs(game.alignErr()) <= cfg.tol;
    const rg = A.r - mm * 0.6;
    c.drawCircle(A.x + Math.cos(gA) * rg, A.y + Math.sin(gA) * rg - camY, Math.max(2.5, mm * 0.38), fill(good ? C.gearA : C.ink, good ? 1 : 0.55));
    mark = { a: tB, good };
  }

  // inen dişli
  if (inc) {
    const a = 0.25 + 0.75 * inc.appear;
    drawGear(inc.N, inc.x, inc.y, inc.th, failing ? C.hit : gears.length % 2 ? C.gearB : C.gearA, a);
    if (mark) {
      const rt = inc.r + mm * 0.35;
      c.drawCircle(inc.x + Math.cos(mark.a) * rt, inc.y + Math.sin(mark.a) * rt - camY, Math.max(2.5, mm * 0.38),
        fill(mark.good ? C.gearA : C.hub, (mark.good ? 1 : 0.85) * a));
    }
  }

  // yazılar
  if (state !== 'menu') {
    text(c, placed + ' / ' + cfg.K, 34, 22, P.font(15), fill(C.muted));
    text(c, 'Bölüm ' + level, W - 44, 22, P.font(15), fill(C.muted));
  }
  const top = gears[gears.length - 1];
  const hintY = Math.max(56, (inc ? inc.sy - inc.r : top.y - top.r) - camY - mm * 5);
  if (state === 'hover' && level === 1 && placed === 0) {
    text(c, 'İşaretler yeşillenince dokun', W / 2, hintY, P.font(17), fill(C.muted, 0.55 + 0.45 * Math.sin(nowMs / 300)));
  }
  if (game.nearT > 0) {
    text(c, game.nearMsg, W / 2, hintY - (1 - game.nearT) * 20, P.font(22), fill(C.near, Math.min(1, game.nearT * 1.5)));
  }
  if (state === 'win') {
    const a = Math.min(1, game.winT * 4);
    const y = Math.max(70, top.y - top.r - camY - mm * 6);
    text(c, 'Zincir tamam!', W / 2, y, P.font(26), fill(C.near, a));
    for (let i = 0; i < 3; i++) {
      const on = i < game.earned;
      const pop = game.reduceMotion ? 1 : Math.min(1, Math.max(0, (game.winT - 0.15 - i * 0.12) * 6));
      star(c, W / 2 + (i - 1) * 34, y + 34, 13 * (0.6 + 0.4 * pop), on ? C.gearB : C.post, a * (on ? pop : 1));
    }
  }
  c.restore();
}

function star(c: SkCanvas, x: number, y: number, ro: number, color: string, alpha: number) {
  const b = Skia.PathBuilder.Make();
  for (let i = 0; i < 10; i++) {
    const a = -Math.PI / 2 + i * Math.PI / 5, rr = i % 2 ? ro * 0.45 : ro;
    const px = x + Math.cos(a) * rr, py = y + Math.sin(a) * rr;
    if (i === 0) b.moveTo(px, py); else b.lineTo(px, py);
  }
  c.drawPath(b.close().build(), fill(color, alpha));
}

