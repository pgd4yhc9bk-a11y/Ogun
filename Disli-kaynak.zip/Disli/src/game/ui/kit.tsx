import type { ReactNode } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View, type StyleProp, type TextProps, type ViewStyle } from 'react-native';
import type { Colors } from '../logic';

// Menülerde kullanılan ortak parçalar.

export const FONT = {
  medium: 'Rubik_500Medium',
  bold: 'Rubik_700Bold',
  heavy: 'Rubik_800ExtraBold',
};

// Telefonun yazı boyutu ayarı ne olursa olsun yazılar en fazla 1,2 kat büyür; menüler taşmaz.
export function Txt(props: TextProps) {
  return <Text maxFontSizeMultiplier={1.2} {...props} />;
}

// '#RRGGBB' + saydamlık
export const alpha = (hex: string, a: number) => {
  const n = parseInt(hex.slice(1), 16);
  return `rgba(${n >> 16 & 255},${n >> 8 & 255},${n & 255},${a})`;
};

type BtnProps = {
  C: Colors;
  label: string;
  onPress: () => void;
  kind?: 'primary' | 'ghost' | 'danger';
  small?: boolean;
  style?: StyleProp<ViewStyle>;
};

export function Btn({ C, label, onPress, kind = 'primary', small, style }: BtnProps) {
  const size = small ? 16 : 17.5;
  const bg = kind === 'primary' ? C.gearA : kind === 'danger' ? C.danger : 'transparent';
  const fg = kind === 'ghost' ? C.ink : C.onBtn;
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={label}
      style={({ pressed }) => [
        {
          backgroundColor: bg,
          borderRadius: 12,
          paddingVertical: small ? 9 : 13,
          paddingHorizontal: small ? 18 : 26,
          alignItems: 'center',
          justifyContent: 'center',
        },
        kind === 'ghost' && { borderWidth: 2, borderColor: alpha(C.muted, 0.55) },
        pressed && { transform: [{ scale: 0.97 }] },
        style,
      ]}
    >
      <Txt numberOfLines={1} style={{ fontFamily: FONT.bold, fontSize: size, color: fg }}>
        {label}
      </Txt>
    </Pressable>
  );
}

export function Link({ C, label, onPress }: { C: Colors; label: string; onPress: () => void }) {
  return (
    <Pressable onPress={onPress} accessibilityRole="button" hitSlop={8} style={{ alignSelf: 'center', marginTop: 14 }}>
      <Txt style={{ fontFamily: FONT.medium, fontSize: 15, color: C.muted, textDecorationLine: 'underline' }}>{label}</Txt>
    </Pressable>
  );
}

// Oyun alanının üstünü kaplayan katman. solid: arka plan tam dolu (Bölümler).
export function Overlay({ C, solid, children }: { C: Colors; solid?: boolean; children: ReactNode }) {
  return (
    <View style={[StyleSheet.absoluteFill, { backgroundColor: solid ? C.bg : alpha(C.bg, 0.93) }]}>
      {children}
    </View>
  );
}

// Küçük ekranda ya da büyük yazıda içerik sığmazsa kaydırılır; sığarsa ortada durur.
export function CenterScroll({ children }: { children: ReactNode }) {
  return (
    <ScrollView contentContainerStyle={styles.center} bounces={false} showsVerticalScrollIndicator={false}>
      {children}
    </ScrollView>
  );
}

export function Card({ children }: { children: ReactNode }) {
  return <View style={styles.card}>{children}</View>;
}

export function Menu({ children }: { children: ReactNode }) {
  return <View style={styles.menu}>{children}</View>;
}

export function H1({ C, children }: { C: Colors; children: ReactNode }) {
  return <Txt style={{ fontFamily: FONT.heavy, fontSize: 58, lineHeight: 66, letterSpacing: -1.5, color: C.ink, textAlign: 'center', marginBottom: 8 }}>{children}</Txt>;
}

export function H2({ C, children }: { C: Colors; children: ReactNode }) {
  return <Txt style={{ fontFamily: FONT.heavy, fontSize: 34, lineHeight: 40, letterSpacing: -0.7, color: C.ink, textAlign: 'center', marginBottom: 8 }}>{children}</Txt>;
}

export function P({ C, children, style }: { C: Colors; children: ReactNode; style?: object }) {
  return (
    <Txt style={[{ fontFamily: FONT.medium, fontSize: 16.5, lineHeight: 24.5, color: C.muted, textAlign: 'center', marginBottom: 20 }, style]}>
      {children}
    </Txt>
  );
}

const styles = StyleSheet.create({
  center: { flexGrow: 1, alignItems: 'center', justifyContent: 'center', padding: 20 },
  card: { width: '100%', maxWidth: 330, alignItems: 'stretch' },
  menu: { width: '100%', maxWidth: 272, alignSelf: 'center', gap: 10 },
});
