import { describe, expect, test } from '@jest/globals';
import {
  DisliGame, LAG, MAX_LEVEL, TAU, cfgFor, meshErr, normalizeProgress, rng, starsFor,
  type Fx, type Progress,
} from '../logic';

const make = (p: Partial<Progress> = {}) => {
  const saved: Record<string, unknown> = {};
  const fx: Fx[] = [];
  const g = new DisliGame({ ...normalizeProgress({}), ...p }, {
    save: (k, v) => { saved[k] = v; },
    fx: f => { fx.push(f); },
    change: () => {},
  });
  g.setSize(390, 700);
  return { g, saved, fx };
};

const STEP = 1 / 120;

// Bot: hizayı gördüğü an (|hata| < 0.03) delay saniye sonra dokunur.
function playLevel(g: DisliGame, l: number, delay: number, jitter = () => 0) {
  g.startLevel(l);
  let tapIn = -1;
  for (let i = 0; i < 120 * 90; i++) {
    g.update(STEP);
    if (g.state === 'hover' && tapIn < 0 && Math.abs(g.alignErr()) < 0.03) tapIn = Math.max(0, delay + jitter());
    if (tapIn >= 0) { tapIn -= STEP; if (tapIn < 0 && g.state === 'hover') g.tap(); }
    if (g.state === 'win') return true;
    if (g.state === 'fail') return false;
  }
  return false;
}

describe('dişli hesabı', () => {
  test('oturtulan dişli dönüş boyunca kaymadan kilitli kalır', () => {
    const r = rng(42);
    for (let i = 0; i < 500; i++) {
      const NA = 9 + Math.floor(r() * 12), NB = 9 + Math.floor(r() * 12);
      const psi = -Math.PI / 2 + (r() - 0.5) * 1.4;
      const ratioA = (r() < 0.5 ? -1 : 1) * 16 / NA, offA = r() * TAU, th0 = r() * 10;
      let thB = r() * TAU;
      const err = meshErr(psi, offA + ratioA * th0, NA, thB, NB);
      thB += err * TAU / NB;
      const ratioB = -ratioA * NA / NB, offB = thB - ratioB * th0;
      for (const d of [0, 0.3, 1.7, 5, -2]) {
        const t = th0 + d;
        expect(Math.abs(meshErr(psi, offA + ratioA * t, NA, offB + ratioB * t, NB))).toBeLessThan(1e-9);
      }
    }
  });

  test('hata -0.5..0.5 aralığında', () => {
    const r = rng(7);
    for (let i = 0; i < 200; i++) {
      const e = meshErr(r() * TAU, r() * 20, 9 + Math.floor(r() * 12), r() * 20, 9 + Math.floor(r() * 12));
      expect(e).toBeGreaterThanOrEqual(-0.5);
      expect(e).toBeLessThanOrEqual(0.5);
    }
  });
});

describe('bölüm üretici', () => {
  test('aynı bölüm her zaman aynı üretilir', () => {
    for (const l of [1, 5, 14, 20, 40, 60]) expect(cfgFor(l)).toEqual(cfgFor(l));
  });

  test('prototiple birebir aynı değerler', () => {
    const c5 = cfgFor(5);
    expect(c5.K).toBe(4);
    expect(c5.teeth).toEqual([18, 12, 20, 16]);
    expect(c5.f).toBeCloseTo(1.261321, 5);
    expect(c5.tol).toBeCloseTo(0.233, 6);
    expect(cfgFor(60).K).toBe(8);
  });

  test('zorluk sınırları', () => {
    for (let l = 1; l <= MAX_LEVEL; l++) {
      const c = cfgFor(l);
      expect(c.K).toBeGreaterThanOrEqual(4);
      expect(c.K).toBeLessThanOrEqual(8);
      expect(c.tol).toBeGreaterThanOrEqual(0.17 - 1e-9);
      expect(c.f).toBeLessThanOrEqual(2.41);
      c.teeth.forEach(n => { expect(n).toBeGreaterThanOrEqual(9); expect(n).toBeLessThanOrEqual(20); });
      if (l < 14) expect(c.spin.every(s => s === 0)).toBe(true);
      if (l < 10) expect(c.wobble).toBe(0);
      if (l < 20) expect(c.flip).toBe(0);
    }
  });
});

describe('oynanabilirlik', () => {
  test('gördüğün an dokunursan (60 ms gecikmeyle) 60 bölümün hepsi geçilir', () => {
    const { g } = make();
    for (let l = 1; l <= MAX_LEVEL; l++) expect([l, playLevel(g, l, LAG)]).toEqual([l, true]);
  });

  test('insan gibi dağınık gecikmeyle ilk 10 bölüm rahat geçilir', () => {
    const { g } = make();
    const r = rng(99);
    const jitter = () => (r() - 0.5) * 0.08;       // ±40 ms
    for (let l = 1; l <= 10; l++) {
      let wins = 0;
      for (let k = 0; k < 10; k++) if (playLevel(g, l, 0.09, jitter)) wins++;
      expect([l, wins >= 8]).toEqual([l, true]);
    }
  });

  test('hizasız dokunuş kilitlenir', () => {
    const { g, fx } = make();
    g.startLevel(1);
    for (let i = 0; i < 1000 && g.state === 'hover'; i++) {
      g.update(STEP);
      if (Math.abs(g.alignErr(LAG)) > 0.45) g.tap();
    }
    for (let i = 0; i < 200; i++) g.update(STEP);
    expect(g.state).toBe('fail');
    expect(g.overlay).toBe('fail');
    expect(fx.some(f => f.type === 'fail')).toBe(true);
  });
});

describe('ilerleme', () => {
  test('bölüm bitince sonraki açılır, yıldız kaydedilir', () => {
    const { g, saved } = make();
    expect(playLevel(g, 1, LAG)).toBe(true);
    expect(g.p.unlocked).toBe(2);
    expect(saved.unlocked).toBe(2);
    expect(g.p.stars[0]).toBeGreaterThanOrEqual(1);
    for (let i = 0; i < 400; i++) g.update(STEP);
    expect(g.level).toBe(2);
    expect(g.state).toBe('hover');
  });

  test('yıldız kuralı', () => {
    expect(starsFor(4, 4)).toBe(3);
    expect(starsFor(3, 4)).toBe(3);
    expect(starsFor(2, 4)).toBe(2);
    expect(starsFor(1, 4)).toBe(1);
    expect(starsFor(0, 8)).toBe(1);
  });

  test('yıldız düşmez: daha kötü oyun eski yıldızı silmez', () => {
    const stars = Array(MAX_LEVEL).fill(0); stars[0] = 3;
    const { g } = make({ stars, unlocked: 2 });
    g.startLevel(1);
    for (let i = 0; i < 120 * 60 && g.state !== 'win'; i++) {
      g.update(STEP);
      const e = g.state === 'hover' ? Math.abs(g.alignErr(LAG)) : 1;
      if (e > g.cfg.tol * 0.8 && e < g.cfg.tol * 0.95) g.tap();   // hep kenardan: 1 yıldız
    }
    expect(g.state).toBe('win');
    expect(g.earned).toBe(1);
    expect(g.p.stars[0]).toBe(3);
  });

  test('kilitli bölüm seçilemez', () => {
    const { g } = make();
    g.openLevels();
    g.pickLevel(5);
    expect(g.overlay).toBe('levels');
    g.pickLevel(1);
    expect(g.overlay).toBe(null);
    expect(g.level).toBe(1);
  });

  test('bozuk kayıt güvenle açılır', () => {
    const p = normalizeProgress({ level: 99, unlocked: 'x', stars: [9, -1, 'a'], sound: 'yok' });
    expect(p.unlocked).toBe(1);
    expect(p.level).toBe(1);
    expect(p.stars.slice(0, 3)).toEqual([3, 0, 0]);
    expect(p.stars).toHaveLength(MAX_LEVEL);
    expect(p.sound).toBe(true);
  });

  test('sıfırlama', () => {
    const stars = Array(MAX_LEVEL).fill(2);
    const { g, saved } = make({ stars, unlocked: 30, level: 12 });
    g.askReset();
    expect(g.overlay).toBe('reset');
    g.confirmReset();
    expect(g.p.unlocked).toBe(1);
    expect(g.totalStars).toBe(0);
    expect(saved.level).toBe(1);
    expect(g.overlay).toBe('home');
  });
});

describe('menü ve duraklatma', () => {
  test('oyun sırasında ana menü duraklatır, devam et kaldığı yerden sürdürür', () => {
    const { g } = make();
    g.pressPlay();
    for (let i = 0; i < 30; i++) g.update(STEP);
    const th = g.th0;
    g.goHome();
    expect(g.state).toBe('paused');
    expect(g.overlay).toBe('home');
    for (let i = 0; i < 60; i++) g.update(STEP);
    expect(g.th0).toBe(th);
    g.pressPlay();
    expect(g.state).toBe('hover');
    expect(g.overlay).toBe(null);
  });

  test('menü açıkken dokunuş sayılmaz', () => {
    const { g } = make();
    g.pressPlay();
    g.goHome();
    g.tap();
    expect(g.state).toBe('paused');
  });

  test('kayıptan sonra ana menü ve tekrar dene', () => {
    const { g } = make();
    g.startLevel(1);
    g.update(STEP);
    for (let i = 0; i < 1000 && g.state === 'hover'; i++) { g.update(STEP); if (Math.abs(g.alignErr(LAG)) > 0.45) g.tap(); }
    for (let i = 0; i < 200; i++) g.update(STEP);
    expect(g.overlay).toBe('fail');
    g.retry();
    expect(g.state).toBe('hover');
    expect(g.placed).toBe(0);
    g.goHome(); g.pressPlay();
    expect(g.state).toBe('hover');
  });

  test('ses ayarı kaydedilir', () => {
    const { g, saved } = make();
    g.toggleSound();
    expect(g.soundOn).toBe(false);
    expect(saved.sound).toBe(false);
  });
});
