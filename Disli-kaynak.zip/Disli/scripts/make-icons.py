# Uygulama simgelerini ve mağaza görsellerini üretir.
# Çalıştır: python3 scripts/make-icons.py   (Pillow gerekir)
import math, os
from PIL import Image, ImageDraw, ImageFont

ROOT = os.path.join(os.path.dirname(__file__), '..')
BG = (0x1F, 0x6B, 0x5C, 255)
GOLD = (0xE0, 0xA2, 0x3A, 255)
PALE = (0xE4, 0xED, 0xE8, 255)
TAU = math.pi * 2

def gear_poly(cx, cy, N, m, th):
    r = N * m / 2; ra = r + m * 0.8; rd = r - m * 1.0; pa = TAU / N
    pts = []
    for i in range(N):
        a = th + i * pa
        for rr, da in ((rd, -0.5), (rd, -0.32), (ra, -0.18), (ra, 0.18), (rd, 0.32)):
            pts.append((cx + math.cos(a + da * pa) * rr, cy + math.sin(a + da * pa) * rr))
    return pts, r

def draw_gear(d, cx, cy, N, m, th, color, hole):
    pts, r = gear_poly(cx, cy, N, m, th)
    d.polygon(pts, fill=color)
    hr = max(4, r * 0.2)
    d.ellipse((cx - hr, cy - hr, cx + hr, cy + hr), fill=hole)
    if r > m * 4.5:
        n = 6 if r > m * 7.5 else 4
        for k in range(n):
            a = th + (k + 0.5) * TAU / n
            x, y, h = cx + math.cos(a) * r * 0.52, cy + math.sin(a) * r * 0.52, r * 0.15
            d.ellipse((x - h, y - h, x + h, y + h), fill=hole)

def pair(size, scale, big_col, small_col, hole, bg=None, offset=(0, 0)):
    S = size * 2   # 2x çiz, sonra küçült (kenar yumuşatma)
    img = Image.new('RGBA', (S, S), bg or (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    m = S * scale
    NA, NB = 16, 10
    psi = -math.pi / 4
    pa = TAU / NA
    thA = psi - pa * 0.5          # A'nın boşluğu temas çizgisinde
    thB = psi + math.pi           # B'nin dişi A'ya bakıyor
    dist = (NA + NB) * m / 2
    # iki dişlinin kapladığı alanı ortala
    ra, rb = NA * m / 2 + m, NB * m / 2 + m
    bx, by = math.cos(psi) * dist, math.sin(psi) * dist
    minx, maxx = min(-ra, bx - rb), max(ra, bx + rb)
    miny, maxy = min(-ra, by - rb), max(ra, by + rb)
    ox = S / 2 - (minx + maxx) / 2 + offset[0] * S
    oy = S / 2 - (miny + maxy) / 2 + offset[1] * S
    draw_gear(d, ox, oy, NA, m, thA, big_col, hole)
    draw_gear(d, ox + bx, oy + by, NB, m, thB, small_col, hole)
    return img.resize((size, size), Image.LANCZOS)

A = os.path.join(ROOT, 'assets')
pair(1024, 0.03, GOLD, PALE, BG, bg=BG).save(os.path.join(A, 'icon.png'))
pair(1024, 0.02, GOLD, PALE, (0, 0, 0, 0)).save(os.path.join(A, 'android-icon-foreground.png'))
Image.new('RGBA', (1024, 1024), BG).save(os.path.join(A, 'android-icon-background.png'))
W = (255, 255, 255, 255)
pair(1024, 0.02, W, W, (0, 0, 0, 0)).save(os.path.join(A, 'android-icon-monochrome.png'))
pair(1024, 0.03, GOLD, PALE, BG, bg=BG).resize((48, 48), Image.LANCZOS).save(os.path.join(A, 'favicon.png'))

G = os.path.join(ROOT, 'store', 'google-play')
os.makedirs(G, exist_ok=True)
pair(1024, 0.03, GOLD, PALE, BG, bg=BG).resize((512, 512), Image.LANCZOS).save(os.path.join(G, 'icon-512.png'))

# Öne çıkan görsel 1024x500
fg = Image.new('RGBA', (1024, 500), BG)
gears = pair(500, 0.03, GOLD, PALE, BG)
fg.alpha_composite(gears, (560, 0))
d = ImageDraw.Draw(fg)
font_path = os.path.join(ROOT, 'node_modules', '@expo-google-fonts', 'rubik', '800ExtraBold', 'Rubik_800ExtraBold.ttf')
small_path = os.path.join(ROOT, 'node_modules', '@expo-google-fonts', 'rubik', '500Medium', 'Rubik_500Medium.ttf')
if os.path.exists(font_path):
    d.text((70, 150), 'Dişli', font=ImageFont.truetype(font_path, 150), fill=PALE)
    d.text((76, 330), 'Dişi boşluğa denk getir, zinciri kur.', font=ImageFont.truetype(small_path, 30), fill=(0xCF, 0xE0, 0xD8, 255))
fg.convert('RGB').save(os.path.join(G, 'feature-graphic.png'))
print('tamam')
