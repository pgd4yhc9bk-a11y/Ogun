import { useCallback, useEffect, useRef, useState } from 'react';
import { Animated, StyleSheet, View } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import * as SplashScreen from 'expo-splash-screen';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import AslanIntro from './src/intro/AslanIntro';
import GameScreen from './src/GameScreen';
import { shouldShowIntro, trackActivity } from './src/introGate';
import { loadSoundOn } from './src/game/storage';

SplashScreen.preventAutoHideAsync().catch(() => {});

type Phase = 'loading' | 'intro' | 'game';
const hideSplash = () => { SplashScreen.hideAsync().catch(() => {}); };

export default function App() {
  const [phase, setPhase] = useState<Phase>('loading');
  const [introMounted, setIntroMounted] = useState(false);
  const [soundOn, setSoundOn] = useState(true);
  const fade = useRef(new Animated.Value(1)).current;
  const introShown = useRef(false);

  useEffect(() => {
    let untrack = () => {};
    let alive = true;
    // Oyun bir sebeple hazır olamazsa açılış ekranı sonsuza kadar kalmasın.
    const fallback = setTimeout(hideSplash, 4000);
    (async () => {
      const [show, sound] = await Promise.all([shouldShowIntro(), loadSoundOn()]);   // önce oku, sonra takibe başla
      if (!alive) return;
      setSoundOn(sound);
      untrack = trackActivity();
      introShown.current = show;
      setIntroMounted(show);
      setPhase(show ? 'intro' : 'game');
      // Intro gösterilecekse açılış ekranı hemen kalkar (intro aynı zeminde başlar).
      // Gösterilmeyecekse oyun hazır olunca kalkar: renk sıçraması olmaz.
      if (show) hideSplash();
    })();
    return () => { alive = false; clearTimeout(fallback); untrack(); };
  }, []);

  const gameReady = useCallback(() => { if (!introShown.current) hideSplash(); }, []);

  const introDone = () => {
    setPhase('game');
    Animated.timing(fade, { toValue: 0, duration: 280, useNativeDriver: true })
      .start(() => setIntroMounted(false));
  };

  return (
    <SafeAreaProvider>
      <StatusBar style="auto" />
      <View style={styles.root}>
        {/* oyun intro sırasında arkada yüklenir, geçişte bekleme olmaz */}
        {phase !== 'loading' && <GameScreen visible={phase === 'game'} onReady={gameReady} />}
        {introMounted && (
          <Animated.View style={[StyleSheet.absoluteFill, { opacity: fade }]} pointerEvents={phase === 'intro' ? 'auto' : 'none'}>
            <AslanIntro onDone={introDone} muted={!soundOn} />
          </Animated.View>
        )}
      </View>
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({ root: { flex: 1 } });
