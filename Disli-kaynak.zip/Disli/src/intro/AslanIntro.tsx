import { useCallback, useEffect, useRef } from 'react';
import { Pressable, StyleSheet, useColorScheme } from 'react-native';
import LottieView from 'lottie-react-native';
import { setAudioModeAsync, useAudioPlayer, useAudioPlayerStatus } from 'expo-audio';

type Props = {
  onDone: () => void;
  dark?: boolean;      // verilmezse telefonun temasına uyar
  muted?: boolean;     // oyunun ses ayarı kapalıysa true ver
  skippable?: boolean; // dokununca geç
};

const BG = { light: '#FBF5EA', dark: '#1D1813' };
const SPEED = 1.2;     // ses bu hıza göre hazırlandı, değiştirme
const SAFETY_MS = 4500;

// Aslan İnteraktif Studios açılışı: 2,5 sn, sesli, döngü yok.
export default function AslanIntro({ onDone, dark, muted = false, skippable = true }: Props) {
  const scheme = useColorScheme();
  const isDark = dark ?? scheme === 'dark';
  const anim = useRef<LottieView>(null);
  const player = useAudioPlayer(require('./aslan-intro.m4a'));
  const status = useAudioPlayerStatus(player);
  const started = useRef(false);
  const finished = useRef(false);
  // start/finish sabit kalsın diye güncel değerler buradan okunur (ilk effect'te güncellenir)
  const cur = useRef({ muted, onDone, player });
  useEffect(() => { cur.current = { muted, onDone, player }; });

  const start = useCallback(() => {
    if (started.current) return;
    started.current = true;
    if (!cur.current.muted) cur.current.player.play();
    anim.current?.play();
  }, []);

  const finish = useCallback(() => {
    if (finished.current) return;
    finished.current = true;
    cur.current.onDone();
  }, []);

  useEffect(() => {
    // sessiz moddaysa ses çalmaz, kullanıcının müziğini de kesmez
    setAudioModeAsync({ playsInSilentMode: false, interruptionMode: 'mixWithOthers' }).catch(() => {});
    if (cur.current.muted) start();
    const wait = setTimeout(start, 600);          // ses geç yüklenirse animasyon beklemesin
    const safety = setTimeout(finish, SAFETY_MS); // bitiş olayı gelmezse yine de devam et
    return () => { clearTimeout(wait); clearTimeout(safety); };
  }, [start, finish]);

  // ses hazır olunca animasyonla aynı anda başlat: senkron kaymaz
  useEffect(() => { if (status.isLoaded) start(); }, [status.isLoaded, start]);

  const skip = () => {
    if (!skippable) return;
    player.pause();
    finish();
  };

  return (
    <Pressable
      onPress={skip}
      accessibilityLabel="Aslan İnteraktif Studios"
      style={[styles.root, { backgroundColor: isDark ? BG.dark : BG.light }]}
    >
      <LottieView
        ref={anim}
        source={isDark ? require('./aslan-intro-koyu.json') : require('./aslan-intro.json')}
        autoPlay={false}
        loop={false}
        speed={SPEED}
        onAnimationFinish={finish}
        style={styles.anim}
      />
    </Pressable>
  );
}

const styles = StyleSheet.create({
  root: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, alignItems: 'center', justifyContent: 'center' },
  anim: { width: '86%', aspectRatio: 1 },
});
